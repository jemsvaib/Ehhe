### Rapidleech on Ubuntu

Build and Edited from https://github.com/Th3-822/rapidleech

* Use Ubuntu 22.04 as 22.10 is not fully supported because of PHP 7.4 unavailablity.

````
bash <(curl -s https://cdn.jsdelivr.net/gh/PBhadoo/Rapidleech@1.4/rapidleech.sh)
````

Deployed at https://gcp.apranet.eu.org Domain Changed
Visit https://telegam.dog/Transload

### Make pull requests for changes or fixes.
