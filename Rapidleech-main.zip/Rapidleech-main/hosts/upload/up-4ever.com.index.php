<?php
$upload_services[] = 'up-4ever.com';
$max_file_size['up-4ever.com'] = 0; // Filesize limit (MB)
$page_upload['up-4ever.com'] = 'up-4ever.com.php';