<?php
$upload_services[] = "letitbit.net_member";
$max_file_size["letitbit.net_member"] = 2000;
$page_upload["letitbit.net_member"] = "letitbit.net_member.php";
?>