<?php
$upload_services[] = 'tusfiles.net_member';
$max_file_size['tusfiles.net_member'] = 2048;
$page_upload['tusfiles.net_member'] = 'tusfiles.net_member.php';
?>
