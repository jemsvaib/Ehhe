<?php
$upload_services[] = 'datafilehost.com';
$max_file_size['datafilehost.com'] = 512;
$page_upload['datafilehost.com'] = 'datafilehost.com.php';
?>