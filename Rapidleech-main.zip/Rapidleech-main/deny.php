<?php

require_once('rl_init.php');

// Access denied page
include(TEMPLATE_DIR.'header.php');
echo('<div align="center"><h1>'.lang(1).'</h1><p>'.lang(2).'</p></div>');
include(TEMPLATE_DIR.'footer.php');

?>